def say_hello(param):
    return param + '!'
