from setuptools import setup

setup(
    name='python_tutorial_demo_app',
    version='1.0.0',
    packages=['roboter', 'roboter.views', 'roboter.controller'],
    url='',
    license='Free',
    author='taishiyamada',
    author_email='',
    description=''
)
